/*
This code base own by Tanmoy Samnata
Devlopment Starter form - 10 jun 2026

*/

import 'dart:async' as async;
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flame/components.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const ZomatoMasterApp());
}

class ZomatoMasterApp extends StatelessWidget {
  const ZomatoMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zomato V5',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFFE23744),
        scaffoldBackgroundColor: const Color(0xFFF4F4F6),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      home: const AuthStateWrapper(),
    );
  }
}

class AuthStateWrapper extends StatelessWidget {
  const AuthStateWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const LoadingSkeleton();
        }
        if (snapshot.hasData && snapshot.data != null) {
          return const MainNavigationScreen();
        }
        return const PhoneAuthScreen();
      },
    );
  }
}

enum AuthView { landing, whatsappPhone, whatsappOtp }

class PhoneAuthScreen extends StatefulWidget {
  const PhoneAuthScreen({super.key});

  @override
  State<PhoneAuthScreen> createState() => _PhoneAuthScreenState();
}

class _PhoneAuthScreenState extends State<PhoneAuthScreen> {
  AuthView _currentView = AuthView.landing;
  bool _isChina = false;
  bool _isLoading = false;

  final _phoneController = TextEditingController();
  final _otpController = TextEditingController();
  final _otpFocusNode = FocusNode();
  String? _simulatedOtp;
  int _countdown = 30;
  async.Timer? _timer;

  void _triggerHaptic() => HapticFeedback.lightImpact();
  void _triggerHapticSuccess() => HapticFeedback.mediumImpact();

  @override
  void initState() {
    super.initState();
    // Auto-detect China region based on system locale
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final locale = WidgetsBinding.instance.platformDispatcher.locale;
      if (locale.countryCode == 'CN' || locale.languageCode == 'zh') {
        setState(() {
          _isChina = true;
        });
      }
    });
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _otpController.dispose();
    _otpFocusNode.dispose();
    _timer?.cancel();
    super.dispose();
  }

  void _startOtpTimer() {
    _countdown = 30;
    _timer?.cancel();
    _timer = async.Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;
      if (_countdown == 0) {
        setState(() => _timer?.cancel());
      } else {
        setState(() => _countdown--);
      }
    });
  }

  Future<void> _loginOrCreateFirebaseUser(String email, String password) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email,
          password: password,
        );
      } else {
        rethrow;
      }
    }
  }

  void _showErrorSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFFE23744),
      ),
    );
  }

  void _showGoogleAccountPicker() {
    _triggerHaptic();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _GoogleAccountPickerSheet(
        onAccountSelected: (name, email) async {
          Navigator.pop(context);
          setState(() => _isLoading = true);
          final dummyEmail = "google_${email.replaceAll('@', '_at_')}@zomatoclone.com";
          try {
            await _loginOrCreateFirebaseUser(dummyEmail, "google_mock_auth_pw");
            _triggerHapticSuccess();
          } catch (e) {
            _showErrorSnackBar(e.toString());
            setState(() => _isLoading = false);
          }
        },
      ),
    );
  }

  void _showWeixinAuthSheet() {
    _triggerHaptic();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _WeixinAuthSheet(
        onAuthorized: (nickname) async {
          Navigator.pop(context);
          setState(() => _isLoading = true);
          final dummyEmail = "weixin_${nickname.toLowerCase()}@zomatoclone.com";
          try {
            await _loginOrCreateFirebaseUser(dummyEmail, "weixin_mock_auth_pw");
            _triggerHapticSuccess();
          } catch (e) {
            _showErrorSnackBar(e.toString());
            setState(() => _isLoading = false);
          }
        },
      ),
    );
  }

  void _sendWhatsAppOtp() {
    _triggerHaptic();
    if (_phoneController.text.trim().length < 8) {
      _showErrorSnackBar("Please enter a valid phone number");
      return;
    }
    setState(() {
      _isLoading = true;
    });

    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!mounted) return;
      final randomOtp = (100000 + (900000 * (DateTime.now().millisecondsSinceEpoch % 1000) / 1000)).toInt().toString();
      setState(() {
        _isLoading = false;
        _simulatedOtp = randomOtp;
        _currentView = AuthView.whatsappOtp;
        _otpController.clear();
      });
      _startOtpTimer();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.key_rounded, color: Colors.yellowAccent),
              const SizedBox(width: 8),
              Text(
                'Simulated WhatsApp OTP: $randomOtp',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          backgroundColor: const Color(0xFFE23744),
          duration: const Duration(seconds: 10),
          action: SnackBarAction(
            label: 'AUTOFILL',
            textColor: Colors.white,
            onPressed: () {
              _otpController.text = randomOtp;
              setState(() {});
              _verifyWhatsAppOtp();
            },
          ),
        ),
      );
    });
  }

  Future<void> _verifyWhatsAppOtp() async {
    _triggerHaptic();
    if (_otpController.text.trim() != _simulatedOtp && _otpController.text.trim() != '123456') {
      _showErrorSnackBar("Invalid OTP code. Please try again.");
      return;
    }

    setState(() => _isLoading = true);
    final phoneClean = _phoneController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final dummyEmail = "whatsapp_$phoneClean@zomatoclone.com";

    try {
      await _loginOrCreateFirebaseUser(dummyEmail, "whatsapp_mock_auth_pw");
      _triggerHapticSuccess();
    } catch (e) {
      _showErrorSnackBar(e.toString());
      setState(() => _isLoading = false);
    }
  }

  Future<void> _skipAuthentication() async {
    _triggerHaptic();
    setState(() => _isLoading = true);
    try {
      await FirebaseAuth.instance.signInAnonymously();
      _triggerHapticSuccess();
    } catch (e) {
      debugPrint("Anonymous sign-in failed ($e). Falling back to Guest User account.");
      try {
        await _loginOrCreateFirebaseUser("guest_user@zomatoclone.com", "guest_mock_auth_pw");
        _triggerHapticSuccess();
      } catch (err) {
        _showErrorSnackBar("Authentication failed: $err");
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCFCFD),
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFCFCFD), Color(0xFFFFF2F3)],
                ),
              ),
            ),
          ),
          Positioned(
            top: 48,
            right: 24,
            child: GestureDetector(
              onTap: () {
                _triggerHaptic();
                setState(() {
                  _isChina = !_isChina;
                  _currentView = AuthView.landing;
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.08),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    )
                  ],
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_isChina ? '🇨🇳 China Mode' : '🌐 Global Mode',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black87)),
                    const SizedBox(width: 4),
                    const Icon(Icons.swap_horiz, size: 14, color: Colors.grey),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 32.0),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _buildCurrentView(),
                ),
              ),
            ),
          ),
          if (_isLoading)
            Positioned.fill(
              child: Container(
                color: Colors.black26,
                child: const Center(
                  child: CircularProgressIndicator(color: Color(0xFFE23744)),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCurrentView() {
    switch (_currentView) {
      case AuthView.landing:
        return _buildLandingView();
      case AuthView.whatsappPhone:
        return _buildWhatsappPhoneView();
      case AuthView.whatsappOtp:
        return _buildWhatsappOtpView();
    }
  }

  Widget _buildLandingView() {
    return Column(
      key: const ValueKey('landing'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(Icons.room_service_rounded, size: 90, color: Color(0xFFE23744)),
        const SizedBox(height: 32),
        const Text(
          'Zomato V5',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: -1.0, color: Color(0xFFE23744)),
        ),
        const SizedBox(height: 8),
        Text(
          'India\'s #1 Food Delivery & Dining App',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, color: Colors.grey.shade600, fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 48),
        ElevatedButton.icon(
          onPressed: () {
            _triggerHaptic();
            setState(() {
              _currentView = AuthView.whatsappPhone;
            });
          },
          icon: const Icon(Icons.chat_bubble_rounded, color: Colors.white),
          label: const Text('Continue with WhatsApp', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF25D366),
            padding: const EdgeInsets.symmetric(vertical: 18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 2,
            shadowColor: const Color(0xFF25D366).withValues(alpha: 0.3),
          ),
        ),
        const SizedBox(height: 16),
        if (!_isChina)
          OutlinedButton.icon(
            onPressed: _showGoogleAccountPicker,
            icon: Image.network(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/1024px-Google_%22G%22_logo.svg.png',
              height: 20,
              width: 20,
              errorBuilder: (c, e, s) => const Icon(Icons.g_mobiledata, size: 20, color: Colors.grey),
            ),
            label: const Text('Continue with Google', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.black87)),
            style: OutlinedButton.styleFrom(
              backgroundColor: Colors.white,
              side: BorderSide(color: Colors.grey.shade300),
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
          )
        else
          ElevatedButton.icon(
            onPressed: _showWeixinAuthSheet,
            icon: const Icon(Icons.chat_bubble_outline_rounded, color: Colors.white),
            label: const Text('Continue with Weixin / 微信登录', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF07C160),
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 2,
              shadowColor: const Color(0xFF07C160).withValues(alpha: 0.3),
            ),
          ),
        const SizedBox(height: 32),
        TextButton(
          onPressed: _skipAuthentication,
          child: Text(
            'Skip for now',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade600,
              decoration: TextDecoration.underline,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildWhatsappPhoneView() {
    return Column(
      key: const ValueKey('whatsappPhone'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              onPressed: () {
                _triggerHaptic();
                setState(() {
                  _currentView = AuthView.landing;
                });
              },
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Text(
          'WhatsApp Login',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: -0.5),
        ),
        const SizedBox(height: 8),
        Text(
          'Enter your WhatsApp number to receive a verification OTP code.',
          style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
        ),
        const SizedBox(height: 32),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F4F6),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                _isChina ? '+86' : '+91',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: _glassInputDecoration('WhatsApp Number', Icons.phone),
              ),
            ),
          ],
        ),
        const SizedBox(height: 32),
        ElevatedButton(
          onPressed: _sendWhatsAppOtp,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF25D366),
            padding: const EdgeInsets.symmetric(vertical: 20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 2,
            shadowColor: const Color(0xFF25D366).withValues(alpha: 0.3),
          ),
          child: const Text('Send Verification Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      ],
    );
  }

  Widget _buildWhatsappOtpView() {
    return Column(
      key: const ValueKey('whatsappOtp'),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              onPressed: () {
                _triggerHaptic();
                setState(() {
                  _currentView = AuthView.whatsappPhone;
                });
              },
            ),
          ],
        ),
        const SizedBox(height: 16),
        const Text(
          'Verify OTP',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: -0.5),
        ),
        const SizedBox(height: 8),
        Text(
          'Enter the 6-digit code sent via WhatsApp to ${_isChina ? "+86" : "+91"} ${_phoneController.text}',
          style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
        ),
        const SizedBox(height: 32),
        _buildOtpDigitsRow(),
        const SizedBox(height: 32),
        Center(
          child: _countdown > 0
              ? Text(
                  'Resend code in $_countdown seconds',
                  style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w500),
                )
              : TextButton(
                  onPressed: _sendWhatsAppOtp,
                  child: const Text(
                    'Resend Code via WhatsApp',
                    style: TextStyle(color: Color(0xFF25D366), fontWeight: FontWeight.bold),
                  ),
                ),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _verifyWhatsAppOtp,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFE23744),
            padding: const EdgeInsets.symmetric(vertical: 20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            elevation: 2,
            shadowColor: const Color(0xFFE23744).withValues(alpha: 0.3),
          ),
          child: const Text('Verify & Proceed', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      ],
    );
  }

  Widget _buildOtpDigitsRow() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Opacity(
          opacity: 0,
          child: SizedBox(
            width: double.infinity,
            height: 55,
            child: TextField(
              controller: _otpController,
              focusNode: _otpFocusNode,
              keyboardType: TextInputType.number,
              maxLength: 6,
              onChanged: (val) {
                setState(() {});
                if (val.length == 6) {
                  _verifyWhatsAppOtp();
                }
              },
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            _otpFocusNode.requestFocus();
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(6, (index) {
              String char = "";
              if (_otpController.text.length > index) {
                char = _otpController.text[index];
              }
              bool isFocused = _otpController.text.length == index;
              return Container(
                width: 45,
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFFF4F4F6),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isFocused ? const Color(0xFFE23744) : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Text(
                  char,
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
                ),
              );
            }),
          ),
        ),
      ],
    );
  }

  InputDecoration _glassInputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: Colors.grey[600]),
      filled: true,
      fillColor: const Color(0xFFF4F4F6),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFFE23744), width: 2)),
    );
  }
}

class _GoogleAccountPickerSheet extends StatelessWidget {
  final Function(String name, String email) onAccountSelected;
  const _GoogleAccountPickerSheet({required this.onAccountSelected});

  @override
  Widget build(BuildContext context) {
    final accounts = [
      {'name': 'Tanmoy Sen', 'email': 'tanmoy.sen@gmail.com', 'avatar': 'TS'},
      {'name': 'Zomato Tester', 'email': 'test.zomato@gmail.com', 'avatar': 'ZT'},
      {'name': 'Developer Guest', 'email': 'dev.guest@gmail.com', 'avatar': 'DG'},
    ];

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Image.network(
                'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/1024px-Google_%22G%22_logo.svg.png',
                height: 24,
                width: 24,
                errorBuilder: (c, e, s) => const Icon(Icons.g_mobiledata, size: 24, color: Colors.blue),
              ),
              const SizedBox(width: 12),
              const Text(
                'Sign in with Google',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: -0.5),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Choose an account to continue to Zomato V5',
            style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
          ),
          const SizedBox(height: 24),
          ...accounts.map((acc) {
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              color: const Color(0xFFF8F9FA),
              elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: const Color(0xFFE23744).withValues(alpha: 0.1),
                  child: Text(
                    acc['avatar']!,
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE23744)),
                  ),
                ),
                title: Text(
                  acc['name']!,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  acc['email']!,
                  style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                ),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                onTap: () => onAccountSelected(acc['name']!, acc['email']!),
              ),
            );
          }),
          const SizedBox(height: 16),
          TextButton(
            onPressed: () => onAccountSelected('Guest Google', 'guest.google@gmail.com'),
            child: const Text('Use another account', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

class _WeixinAuthSheet extends StatelessWidget {
  final Function(String nickname) onAuthorized;
  const _WeixinAuthSheet({required this.onAuthorized});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  color: Color(0xFF07C160),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.chat_bubble_rounded, size: 16, color: Colors.white),
              ),
              const SizedBox(width: 12),
              const Text(
                'WeChat Login (微信登录)',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: -0.5),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: const Color(0xFFE23744),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.room_service_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Zomato V5 requesting access to:',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '• Your public profile info (avatar, nickname, gender, region)',
                      style: TextStyle(color: Colors.black87, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 48),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey.shade100,
                    foregroundColor: Colors.black87,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Cancel / 拒绝', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => onAuthorized('WeChatUser_${(1000 + (9000 * (DateTime.now().millisecondsSinceEpoch % 1000) / 1000)).toInt()}'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF07C160),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Allow / 允许', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});
  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: const [DeliveryTab(), ProfileTab()],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: const Color(0xFFE23744),
        onTap: (i) {
          HapticFeedback.selectionClick();
          setState(() => _currentIndex = i);
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.delivery_dining_rounded), label: 'Delivery'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'Profile'),
        ],
      ),
    );
  }
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final email = user?.email ?? '';
    final isAnonymous = user?.isAnonymous ?? true;

    String authType = 'Guest';
    String identifier = 'Guest User';
    IconData authIcon = Icons.person_rounded;
    Color authColor = Colors.grey;

    if (isAnonymous) {
      authType = 'Guest Access';
      identifier = 'Anonymous (Saved Temporarily)';
      authIcon = Icons.fingerprint;
      authColor = Colors.orange;
    } else if (email.startsWith('whatsapp_')) {
      authType = 'WhatsApp OTP';
      final cleanNum = email.replaceAll('whatsapp_', '').replaceAll('@zomatoclone.com', '');
      identifier = '+$cleanNum';
      authIcon = Icons.chat_bubble_rounded;
      authColor = const Color(0xFF25D366);
    } else if (email.startsWith('google_')) {
      authType = 'Google Account';
      identifier = email.replaceAll('google_', '').replaceAll('_at_', '@').replaceAll('@zomatoclone.com', '');
      authIcon = Icons.g_mobiledata;
      authColor = Colors.blue;
    } else if (email.startsWith('weixin_')) {
      authType = 'Weixin (WeChat)';
      identifier = email.replaceAll('weixin_', '').replaceAll('@zomatoclone.com', '');
      authIcon = Icons.chat_bubble_outline_rounded;
      authColor = const Color(0xFF07C160);
    } else if (email.contains('@zomatoclone.com')) {
      authType = 'Phone & Password';
      identifier = email.replaceAll('@zomatoclone.com', '');
      authIcon = Icons.phone_android;
      authColor = const Color(0xFFE23744);
    } else {
      authType = 'Firebase Account';
      identifier = email;
      authIcon = Icons.email_rounded;
      authColor = const Color(0xFFE23744);
    }

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'My Profile',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -0.5),
            ),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: authColor.withValues(alpha: 0.1),
                    child: Icon(authIcon, size: 40, color: authColor),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    authType,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: authColor,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    identifier,
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'UID: ${user?.uid != null && user!.uid.length > 8 ? user.uid.substring(0, 8) : "Unknown"}...',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  )
                ],
              ),
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.shopping_bag_rounded, color: Color(0xFFE23744)),
                    title: const Text('Your Orders', style: TextStyle(fontWeight: FontWeight.bold)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14),
                    onTap: () {},
                  ),
                  const Divider(height: 1, indent: 56),
                  ListTile(
                    leading: const Icon(Icons.wallet_rounded, color: Colors.purple),
                    title: const Text('Payment Methods', style: TextStyle(fontWeight: FontWeight.bold)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14),
                    onTap: () {},
                  ),
                  const Divider(height: 1, indent: 56),
                  ListTile(
                    leading: const Icon(Icons.card_membership_rounded, color: Colors.amber),
                    title: const Text('Zomato Gold', style: TextStyle(fontWeight: FontWeight.bold)),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.amber.shade100,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'ACTIVATE',
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.amber),
                      ),
                    ),
                    onTap: () {},
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: () async {
                HapticFeedback.heavyImpact();
                await FirebaseAuth.instance.signOut();
              },
              icon: const Icon(Icons.logout_rounded, color: Colors.white),
              label: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE23744),
                padding: const EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                elevation: 4,
                shadowColor: const Color(0xFFE23744).withValues(alpha: 0.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DeliveryTab extends StatelessWidget {
  const DeliveryTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Row(
              children: [
                const Icon(Icons.location_on, color: Color(0xFFE23744), size: 28),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Home',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: Colors.grey[800])),
                    Text('123 Tech Street, Dev City', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                  ],
                ),
                const Spacer(),
                CircleAvatar(backgroundColor: Colors.grey[300], child: const Icon(Icons.person, color: Colors.white)),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('restaurants')
                  .snapshots(includeMetadataChanges: true),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const LoadingSkeleton();

                final isOffline = snapshot.data!.metadata.isFromCache;
                final docs = snapshot.data!.docs;

                return CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    if (isOffline)
                      SliverToBoxAdapter(
                        child: Container(
                          color: Colors.orange[100],
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.cloud_off, size: 16, color: Colors.deepOrange),
                              SizedBox(width: 8),
                              Text('Offline mode. Viewing saved data.',
                                  style: TextStyle(
                                      color: Colors.deepOrange, fontWeight: FontWeight.bold, fontSize: 12)),
                            ],
                          ),
                        ),
                      ),
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          final data = docs[index].data() as Map<String, dynamic>;
                          return _buildPremiumCard(context, docs[index].id, data);
                        },
                        childCount: docs.length,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPremiumCard(BuildContext context, String id, Map<String, dynamic> data) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        Navigator.push(context, MaterialPageRoute(builder: (_) => OrderScreen(restaurantId: id, data: data)));
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 20, offset: const Offset(0, 10))],
        ),
        child: Column(
          children: [
            Hero(
              tag: 'hero_$id',
              child: Container(
                height: 180,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  gradient: LinearGradient(colors: [Colors.grey[300]!, Colors.grey[400]!]),
                ),
                alignment: Alignment.bottomRight,
                padding: const EdgeInsets.all(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)]),
                  child: Text('${data['eta']} min',
                      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(data['name'] ?? 'Restaurant',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(data['food_type'] ?? 'Cuisine',
                          style: TextStyle(color: Colors.grey[600], fontSize: 14, fontWeight: FontWeight.w500)),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(color: Colors.green[600], borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        Text('${data['rating'] ?? 'NEW'}',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
                        const SizedBox(width: 4),
                        const Icon(Icons.star, color: Colors.white, size: 14),
                      ],
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class LoadingSkeleton extends StatelessWidget {
  const LoadingSkeleton({super.key});
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.3, end: 1.0),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeInOut,
      builder: (context, opacity, child) => Opacity(opacity: opacity, child: child),
      child: ListView.builder(
        itemCount: 4,
        padding: const EdgeInsets.all(16),
        itemBuilder: (_, __) => Container(
          margin: const EdgeInsets.only(bottom: 24),
          height: 250,
          decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(24)),
        ),
      ),
    );
  }
}

class OrderScreen extends StatelessWidget {
  final String restaurantId;
  final Map<String, dynamic> data;
  OrderScreen({super.key, required this.restaurantId, required this.data});

  final _nameCtrl = TextEditingController(text: "John Doe");
  final _phoneCtrl = TextEditingController();

  Future<void> _placeOrder(BuildContext context) async {
    HapticFeedback.heavyImpact();

    final orderRef = await FirebaseFirestore.instance.collection('orders').add({
      'restaurantName': data['name'],
      'customerName': _nameCtrl.text,
      'whatsappNumber': _phoneCtrl.text,
      'status': 'Preparing',
      'driverLocation': {'x': 100.0, 'y': 600.0},
      'timestamp': FieldValue.serverTimestamp(),
    });

    if (context.mounted) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => TrackingScreen(orderId: orderRef.id, phone: _phoneCtrl.text)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(tag: 'hero_$restaurantId', child: Container(color: Colors.grey[400])),
              title: Text(data['name'],
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 10)])),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Delivery Info', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 24),
                  TextField(
                      controller: _nameCtrl,
                      decoration: InputDecoration(
                          labelText: 'Recipient Name',
                          filled: true,
                          fillColor: Colors.grey[100],
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
                  const SizedBox(height: 16),
                  TextField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                          labelText: 'WhatsApp Number',
                          filled: true,
                          fillColor: Colors.grey[100],
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
                  const SizedBox(height: 48),
                  ElevatedButton(
                    onPressed: () => _placeOrder(context),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE23744),
                        minimumSize: const Size(double.infinity, 60),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    child: const Text('Confirm Order',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

class TrackingScreen extends StatefulWidget {
  final String orderId;
  final String phone;
  const TrackingScreen({super.key, required this.orderId, required this.phone});

  @override
  State<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends State<TrackingScreen> {
  late CityTrackerGame _game;
  async.Timer? _sim;
  double dX = 100, dY = 600;

  @override
  void initState() {
    super.initState();
    _game = CityTrackerGame();
    _sim = async.Timer.periodic(const Duration(seconds: 1), (t) {
      dY -= 20;
      dX += 5;
      String status = 'Preparing';
      if (dY < 450) status = 'On the Way';
      if (dY < 150) {
        status = 'Arrived';
        t.cancel();
      }

      FirebaseFirestore.instance.collection('orders').doc(widget.orderId).update({
        'driverLocation': {'x': dX, 'y': dY},
        'status': status,
      });
    });
  }

  @override
  void dispose() {
    _sim?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('orders')
            .doc(widget.orderId)
            .snapshots(includeMetadataChanges: true),
        builder: (context, snapshot) {
          final data = snapshot.data?.data() as Map<String, dynamic>? ?? {};
          final status = data['status'] ?? 'Connecting...';
          final isOffline = snapshot.data?.metadata.isFromCache ?? false;

          if (data['driverLocation'] != null) {
            _game.updatePosition(Vector2(
                data['driverLocation']['x'].toDouble(), data['driverLocation']['y'].toDouble()));
          }

          return Stack(
            children: [
              Positioned.fill(child: GameWidget(game: _game)),
              if (isOffline)
                Positioned(
                  top: 50,
                  left: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        color: Colors.orange,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10)]),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.sync_problem, color: Colors.white, size: 20),
                      SizedBox(width: 8),
                      Text('Syncing offline data...',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              Align(
                alignment: Alignment.bottomCenter,
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                    child: Container(
                      padding: const EdgeInsets.all(32),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.85),
                        border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.5), width: 1.5)),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                    color: const Color(0xFFE23744),
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                          color: const Color(0xFFE23744).withValues(alpha: 0.4),
                                          blurRadius: 15,
                                          offset: const Offset(0, 5))
                                    ]),
                                child: const Icon(Icons.two_wheeler_rounded, color: Colors.white, size: 36),
                              ),
                              const SizedBox(width: 20),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(status.toUpperCase(),
                                        style: const TextStyle(
                                            color: Color(0xFFE23744),
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: 1.5)),
                                    const SizedBox(height: 6),
                                    const Text('Arriving soon',
                                        style: TextStyle(
                                            fontSize: 26, fontWeight: FontWeight.w900, color: Colors.black87)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 32),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  icon: const Icon(Icons.chat_bubble_rounded),
                                  label: const Text('WhatsApp'),
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF25D366),
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(vertical: 18),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                      elevation: 0),
                                  onPressed: () => launchUrl(Uri.parse(
                                      "whatsapp://send?phone=${widget.phone}&text=Ready for food!")),
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: ElevatedButton.icon(
                                  icon: const Icon(Icons.fingerprint),
                                  label: const Text('Auth Delivery'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: status == 'Arrived' ? Colors.black : Colors.black12,
                                    foregroundColor: status == 'Arrived' ? Colors.white : Colors.black38,
                                    padding: const EdgeInsets.symmetric(vertical: 18),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                    elevation: 0,
                                  ),
                                  onPressed: status == 'Arrived'
                                      ? () {
                                          HapticFeedback.heavyImpact();
                                          Navigator.pop(context);
                                        }
                                      : null,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              )
            ],
          );
        },
      ),
    );
  }
}

class CityTrackerGame extends FlameGame {
  late TrackerSprite driver;

  @override
  Color backgroundColor() => const Color(0xFFCAD2D3);

  @override
  Future<void> onLoad() async {
    super.onLoad();
    driver = TrackerSprite(position: Vector2(100, 600));
    add(driver);
  }

  @override
  void render(Canvas canvas) {
    final buildingPaint = Paint()..color = const Color(0xFFDDE4E5)..style = PaintingStyle.fill;
    final highlightPaint = Paint()..color = Colors.white..style = PaintingStyle.fill;

    for (int x = -50; x < 600; x += 120) {
      for (int y = -50; y < 900; y += 120) {
        canvas.drawRRect(
            RRect.fromRectAndRadius(Rect.fromLTWH(x.toDouble(), y.toDouble(), 90, 90), const Radius.circular(16)),
            buildingPaint);
        canvas.drawRRect(
            RRect.fromRectAndRadius(Rect.fromLTWH(x.toDouble(), y.toDouble(), 85, 85), const Radius.circular(16)),
            highlightPaint);
      }
    }

    final routePaint = Paint()
      ..color = const Color(0xFFE23744).withValues(alpha: 0.3)
      ..strokeWidth = 12
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(const Offset(100, 600), const Offset(120, 100), routePaint);

    super.render(canvas);
  }

  void updatePosition(Vector2 newPos) => driver.targetPosition = newPos;
}

class TrackerSprite extends PositionComponent {
  Vector2 targetPosition;
  double pulse = 0;

  TrackerSprite({required Vector2 position})
      : targetPosition = position,
        super(position: position, size: Vector2(50, 50));

  @override
  void update(double dt) {
    super.update(dt);
    position.lerp(targetPosition, dt * 4.0);
    pulse = (pulse + dt * 3) % 2;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final center = Offset(size.x / 2, size.y / 2);

    canvas.drawCircle(center, 15 + (pulse * 15),
        Paint()..color = const Color(0xFFE23744).withValues(alpha: (2 - pulse) / 4));
    canvas.drawCircle(Offset(center.dx, center.dy + 4), 14, Paint()..color = Colors.black26);
    canvas.drawCircle(center, 16, Paint()..color = Colors.white);
    canvas.drawCircle(center, 10, Paint()..color = const Color(0xFFE23744));
  }
}
/*
--------------pubspec.yaml----------------

dependencies:
  flutter:
    sdk: flutter
  firebase_core: ^3.0.0
  firebase_auth: ^5.0.0
  cloud_firestore: ^5.0.0
  flame: ^1.16.0
 
  url_launcher: ^6.3.0

-----------------------------------------

*/